#include "color.h"

Color::Color() : BaseColor(){
	//do nothing
}

Color::Color(int _R, int _G, int _B) : BaseColor(_R, _G, _B){
	//do nothing
}
